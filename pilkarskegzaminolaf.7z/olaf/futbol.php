<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="styl.css">
    <title>Rozgrywki futbolowe</title>
</head>
<body>
    <header>
        <h2>Światowe rozgrywki piłkarskie</h2>
        <img src="obraz1.jpg" alt="boisko">
    </header>
   
        <?php
        $serwer ='localhost';
        $uzytkownik='root';
        $dbname='egzamin';
        $password='';

        $db = mysqli_connect($serwer,$uzytkownik,$password,$dbname);
        $q = 'SELECT zespol1, zespol2, wynik, data_rozgrywki FROM `rozgrywka` WHERE zespol1 = "EVG";';
        $result = mysqli_query($db, $q);

        while ($row = mysqli_fetch_array($result)){
            echo '<div class="blokmecze" >
            <h3>'.$row["zespol1"].'-'. $row["zespol2"].'</h3>
            <h4>'.$row["wynik"].'</h4>
            <p>w dniu:'.$row["data_rozgrywki"].'</p>
            </div>';
        }
        ?>
    
  
    <main>
        <h2>Reprezentacja Polski</h2>
    </main>
    <div class="blokl">
        <p>Podaj pozycję zawodników (1-bramkarze, 2-obrońcy, 3-pomocnicy, 4-
            napastnicy):</p>
            <form method="post">
                <input type="number">
                <input type="submit" value="Sprawdz">
            </form>
            <ul>
                skrypt
            </ul>
    </div>
    <div class="blokp">
        <img src="zad1.png" alt="piłkarz">
        <p>Autor:OLAF 69696969696</p>
    </div>


    
</body>
</html>
