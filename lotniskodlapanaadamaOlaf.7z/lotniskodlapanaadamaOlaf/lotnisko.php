<!DOCTYPE html>
<?php
setcookie("user","test", time() +7200,'/');
?>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Port Lotniczy</title>
    <link rel="stylesheet" href="styl5.css">
</head>
<body>
    <header id="ban1">
        <img src="zad5.png" alt="logo lotnisko">

    </header>

    <header id="ban2">
        <h1>Przyloty</h1>
    </header>

    <header id="ban3">
        <h3>przydatne pliki</h3>
        <a href="kwerendy.txt" target="_blank">Pobierz…</a>
    </header>

    <main>
    <table>
                <tr>
                    <th>czas</th>
                    <th>kierunek</th>
                    <th>numer rejsu</th>
                    <th>status</th>
                </tr>
                <?php
                    

                     $serwer = 'localhost';
                     $uzytkownik = 'root';
                     $password = '';
                     $dbname = 'egzamin';
                     $db = mysqli_connect ($serwer,$uzytkownik,$password,$dbname);
                     $q = "SELECT czas, kierunek, nr_rejsu, status_lotu FROM przyloty ORDER BY czas ASC;";
                      
                    $result = $db->query($q);

                    while($row = $result -> fetch_array()) {
                        echo "<tr>";
                            echo "<td>".$row['czas']."</td>";
                            echo "<td>".$row['kierunek']."</td>";
                            echo "<td>".$row['nr_rejsu']."</td>";
                            echo "<td>".$row['status_lotu']."</td>";
                            "</tr>";
                      
                    }
             
                ?>
            </table>
    </main>

    <footer id="stop1">
        
        <?php
        if(!isset($_COOKIE["user"])){
            echo"<p><b>Dzień dobry! strona lotnisko używa ciasteczek</b></p>";
        }   else {
            echo "<p><i>Witaj ponownie na stronie lotniska</i></b>";
        }
        ?>
      

    </footer>

    <footer id="stop2">
        
        Autor:Olaf 69696969696969
       
    </footer>
    
</body>
</html>
